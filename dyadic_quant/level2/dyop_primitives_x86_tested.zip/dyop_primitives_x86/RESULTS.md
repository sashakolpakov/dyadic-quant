# Tested primitive/op-tree result

## Scope

- **Owner target:** Apple `arm64_neon` (not available in this runtime).
- **Test platform:** Linux `x86_64`, AMD virtual CPU exposing AVX2, AVX-512F/BW/VL, FMA and VNNI.
- **Purpose:** test whether the proposed primitive decomposition is executable and capable of crossing the **fixed absolute materialized-tensor runtimes** supplied from the owner's ARM64 tables.
- **Materialized tensors were not executed here.** Their recorded runtimes were loaded as fixed gates.
- Weight packing is an offline/precomputed operation and is excluded from execution timing.

## Tested implementation

- Weight layout: `[N/16][K][16]` signed `int16` codes.
- Core tile: `MR=4`, `NR=16`.
- Core arithmetic: `float32` activations × signed `int16` codes, accumulated in `__m512`.
- Per-output dyadic scale and bias are applied in registers before final writeback.
- GEMM/output projection use output-tile parallelism.
- Embedding uses direct row gather/decode rather than the GEMM weight layout.
- Conv2d uses an MR-window packer feeding the same 4×16 microkernel; 1×1 stride-2 uses a specialized gather path.
- Tiny kernels use persistent spin workers to avoid per-call launch/barrier cost.

## Results

| Subkernel | Fixed ARM gate | AVX-512 native | Ratio vs gate | Threads | Result |
|---|---:|---:|---:|---:|---|
| Qwen sequence GEMM | 0.192396 ms | 0.089499 ms | 2.15× | 28 | PASS |
| Qwen output-projection GEMM | 10.843443 ms | 5.916020 ms | 1.83× | 28 | PASS |
| Qwen embedding | 0.015501 ms | 0.003363 ms | 4.61× | 16 | PASS |
| ResNet 3×3, batch 8 | 3.935540 ms | 2.151598 ms | 1.83× | 28 | PASS |
| ResNet layer2 stride-2 3×3 | 0.347237 ms | 0.124096 ms | 2.80× | 16 | PASS |
| ResNet layer3 stride-2 3×3 | 0.262369 ms | 0.110760 ms | 2.37× | 28 | PASS |
| ResNet layer4 stride-2 3×3 | 0.228865 ms | 0.146546 ms | 1.56× | 28 | PASS |
| ResNet 1×1 downsample | 0.265602 ms | 0.127984 ms | 2.08× | 28 | PASS |
| Standalone global average pool | 0.013332 ms | 0.002824 ms | 4.72× | 16 | PASS |

All rows passed sampled scalar correctness checks. Exact values are in `x86_avx512_gate_results.csv`.

## What this establishes

The previously missing idea is not another layer-level special case. It is a real fused primitive stack:

```
pack_weight_k_nr
  + activation row/window tile
  + MR×NR register microkernel
  + in-register scale/bias
  + final writeback
  + persistent scheduling for tiny calls
```

That stack crossed every supplied absolute gate on the available AVX-512 host. In particular, Conv2d did not need a separate arithmetic core: its window tiles feed the same microkernel as GEMM.

## What this does not establish

This is **not** an ARM-versus-x86 performance comparison and does not prove the NEON port will pass on the Apple machine. Core count, clock, cache, memory system, compiler and vector width differ. It establishes that the op-tree itself is viable and that the former failures were implementation/scheduling failures rather than an inherent cost of direct dyadic execution.

The decisive next experiment is an ARM64/NEON port with the same dataflow, using persistent workers and an ARM-calibrated tile such as MR=4–6, NR=8, run against the existing local gates.
