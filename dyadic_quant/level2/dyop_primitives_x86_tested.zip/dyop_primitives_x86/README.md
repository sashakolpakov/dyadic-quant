# dyop primitive feasibility benchmark (x86-64 AVX-512)

This is a standalone implementation of the primitive stack requested for dyop:

- `pack_weight_k_nr`
- `pack_activation_mr_k`
- `make_indirect_window_tile`
- `microkernel_mr_nr_f32_i16`
- fused `apply_scale_bias`
- contiguous/NCHW `writeback_strided`
- direct embedding decode
- shape-specialized `reduction_window`

The tested profile is AVX-512 with `MR=4`, `NR=16`. The supplied ARM64/NEON runtimes are treated as fixed absolute gates. The benchmark does **not** execute or time materialized tensors, and offline weight packing is excluded.

Build and run:

```bash
make
OMP_PROC_BIND=close OMP_PLACES=cores ./dyop_primitives x86_avx512_gate_results.csv
```

A pass here demonstrates that the op-tree is executable and can cross the recorded absolute gate on this machine. It does not establish that the same absolute result will hold on Apple ARM64; the NEON implementation must be run on the owner target.

## Final result

See `RESULTS.md` and `x86_avx512_gate_results.csv`. All nine previously failing fixed gates pass on the tested AVX-512 implementation. `ARM64_NEON_PORT.md` maps the exact tested dataflow to NEON intrinsics and ARM tile geometry.
